$(function() {
  $switch_anchor = $('#editor_switch a').not('.ie7 #editor_switch a, .ie6 #editor_switch a');
});
